#!/bin/bash

gsutil cp gs://fsbd-23-ih/projekt1/mapper.py .
gsutil cp gs://fsbd-23-ih/projekt1/reducer.py .
gsutil cp gs://fsbd-23-ih/projekt1/hive.hql .
gsutil cp gs://fsbd-23-ih/projekt1/projekt1.py .